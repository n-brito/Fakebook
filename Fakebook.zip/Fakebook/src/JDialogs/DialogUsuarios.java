package JDialogs;

import parteGrafica.TelaOutroUsuario;
import social.Rede;
import social.Usuario;

/**
 *
 * @author Jorge Gomes & Naiara Brito
 */
public class DialogUsuarios extends javax.swing.JDialog {

    /**
     * Creates new form DialogUsuarios
     */
    
    private Usuario atual;
    private String[] listaUsuarios;
    
    public DialogUsuarios(java.awt.Frame parent, boolean modal, Usuario atual) {
        super(parent, modal);
        initComponents();
        this.atual = atual; 
        listaUsuarios = new String[Rede.dados.getUsuarios().size()];
        atualizarTelaDialogUsuarios();
    }
    
    public void atualizarTelaDialogUsuarios(){
        for (int i = 0; i < Rede.dados.getUsuarios().size(); i++) {
            if(Rede.dados.getUsuarios().get(i).getBloqueados().contains(this.atual) == false){
                listaUsuarios[i] = Rede.dados.getUsuarios().get(i).getNome();
            }
        }

        jList1.setListData(listaUsuarios); 
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        BTverUsuario = new javax.swing.JButton();
        jScrollPane3 = new javax.swing.JScrollPane();
        jScrollPane2 = new javax.swing.JScrollPane();
        jList1 = new javax.swing.JList<>();
        BTcancelar = new javax.swing.JToggleButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        BTverUsuario.setText("Ver usuário");
        BTverUsuario.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BTverUsuarioActionPerformed(evt);
            }
        });

        jList1.setModel(new javax.swing.AbstractListModel<String>() {
            String[] strings = { "Item 1", "Item 2", "Item 3", "Item 4", "Item 5" };
            public int getSize() { return strings.length; }
            public String getElementAt(int i) { return strings[i]; }
        });
        jScrollPane2.setViewportView(jList1);

        jScrollPane3.setViewportView(jScrollPane2);

        BTcancelar.setText("Cancelar");
        BTcancelar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BTcancelarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(27, 27, 27)
                .addComponent(BTcancelar)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(BTverUsuario)
                .addGap(49, 49, 49))
            .addGroup(layout.createSequentialGroup()
                .addGap(106, 106, 106)
                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 181, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(118, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(30, 30, 30)
                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 41, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(BTverUsuario)
                    .addComponent(BTcancelar))
                .addGap(76, 76, 76))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void BTverUsuarioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BTverUsuarioActionPerformed
        int index = jList1.getSelectedIndex();
        if(index == -1)
            return;
        Usuario usuarioSelecionado = Rede.dados.getUsuarios().get(index);
        dispose();
        TelaOutroUsuario nova = new TelaOutroUsuario(atual, usuarioSelecionado);
        nova.setLocationRelativeTo(null);
        nova.setVisible(true);
    }//GEN-LAST:event_BTverUsuarioActionPerformed

    private void BTcancelarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BTcancelarActionPerformed
        dispose();
    }//GEN-LAST:event_BTcancelarActionPerformed

    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JToggleButton BTcancelar;
    private javax.swing.JButton BTverUsuario;
    private javax.swing.JList<String> jList1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    // End of variables declaration//GEN-END:variables
}
