package JDialogs;

import javax.swing.JOptionPane;
import parteGrafica.TelaGrupo;
import social.Grupo;
import social.Rede;
import social.Usuario;

/**
 *
 * @author Jorge Gomes & Naiara Brito
 */
public class DialogGrupos extends javax.swing.JDialog {

    /**
     * Creates new form DialogGrupos
     */
    
    private Usuario atual;
    private String[] listaGrupos;
    
    /**
     *
     * @param parent
     * @param modal
     * @param atual
     */
    public DialogGrupos(java.awt.Frame parent, boolean modal, Usuario atual) {
        super(parent, modal);
        initComponents();
        
        this.atual = atual; 
        listaGrupos = new String[Rede.dados.getGrupos().size()];
        
        for (int i = 0; i < Rede.dados.getGrupos().size(); i++) {
            listaGrupos[i] = Rede.dados.getGrupos().get(i).getTitulo();
        }
        
        jList1.setListData(listaGrupos);
    }

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jTabbedPane1 = new javax.swing.JTabbedPane();
        BTentrar = new javax.swing.JButton();
        BTcriarNovoGrupo = new javax.swing.JButton();
        jScrollPane3 = new javax.swing.JScrollPane();
        jScrollPane2 = new javax.swing.JScrollPane();
        jList1 = new javax.swing.JList<>();
        BTcancelar = new javax.swing.JToggleButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        BTentrar.setText("Entrar");
        BTentrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BTentrarActionPerformed(evt);
            }
        });

        BTcriarNovoGrupo.setText("Criar novo grupo");
        BTcriarNovoGrupo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BTcriarNovoGrupoActionPerformed(evt);
            }
        });

        jList1.setModel(new javax.swing.AbstractListModel<String>() {
            String[] strings = { "Item 1", "Item 2", "Item 3", "Item 4", "Item 5" };
            public int getSize() { return strings.length; }
            public String getElementAt(int i) { return strings[i]; }
        });
        jScrollPane2.setViewportView(jList1);

        jScrollPane3.setViewportView(jScrollPane2);

        BTcancelar.setText("Cancelar");
        BTcancelar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BTcancelarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(154, 154, 154)
                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 181, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(layout.createSequentialGroup()
                .addGap(27, 27, 27)
                .addComponent(BTcancelar)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 77, Short.MAX_VALUE)
                .addComponent(BTcriarNovoGrupo)
                .addGap(72, 72, 72)
                .addComponent(BTentrar)
                .addGap(49, 49, 49))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 36, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(BTcriarNovoGrupo)
                    .addComponent(BTentrar)
                    .addComponent(BTcancelar))
                .addGap(76, 76, 76))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void BTentrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BTentrarActionPerformed
        int index = jList1.getSelectedIndex();
        if(index == -1)
            return;
        
        Grupo grupoSelecionado = Rede.dados.getGrupos().get(index);
        dispose();
        
        if(grupoSelecionado.getBloqueados().contains(this.atual)){
            JOptionPane.showMessageDialog(null, "Você foi bloqueado pelo administrador do grupo " + grupoSelecionado.getTitulo());
        }else{
            if(atual.getGrupos().contains(grupoSelecionado)){
                TelaGrupo nova = new TelaGrupo(grupoSelecionado, atual);
                nova.setLocationRelativeTo(null);
                nova.setVisible(true);
            }else{
                DialogPermissaoGrupo novo = new DialogPermissaoGrupo(null,true, this.atual, grupoSelecionado);
                novo.setLocationRelativeTo(null);
                novo.setVisible(true);
            }         
        }
        
    }//GEN-LAST:event_BTentrarActionPerformed

    private void BTcriarNovoGrupoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BTcriarNovoGrupoActionPerformed
        
        dispose();
        DialogCriarGrupo novo = new DialogCriarGrupo(null, true ,this.atual);
        novo.setLocationRelativeTo(null);
        novo.setVisible(true);
        
        
    }//GEN-LAST:event_BTcriarNovoGrupoActionPerformed

    private void BTcancelarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BTcancelarActionPerformed
        dispose();
    }//GEN-LAST:event_BTcancelarActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JToggleButton BTcancelar;
    private javax.swing.JButton BTcriarNovoGrupo;
    private javax.swing.JButton BTentrar;
    private javax.swing.JList<String> jList1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JTabbedPane jTabbedPane1;
    // End of variables declaration//GEN-END:variables
}
