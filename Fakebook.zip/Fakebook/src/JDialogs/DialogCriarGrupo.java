package JDialogs;

import social.Grupo;
import social.Rede;
import social.Usuario;

/**
 *
 * @author Jorge Gomes & Naiara Brito
 */
public class DialogCriarGrupo extends javax.swing.JDialog {

    /**
     * Creates new form DialogCriarGrupo
     */
    
    private Usuario atual;
    
    /**
     *
     * @param parent
     * @param modal
     * @param atual
     */
    public DialogCriarGrupo(java.awt.Frame parent, boolean modal, Usuario atual) {
        super(parent, modal);
        initComponents();
        this.atual = atual;
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        txtNomeGrupo = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        BTcriar = new javax.swing.JButton();
        BTcancelar = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        jLabel1.setText("Título");

        jLabel2.setText("Criar grupo");

        BTcriar.setText("Criar");
        BTcriar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BTcriarActionPerformed(evt);
            }
        });

        BTcancelar.setText("Cancelar");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap(42, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(jLabel1)
                        .addGap(31, 31, 31)
                        .addComponent(txtNomeGrupo, javax.swing.GroupLayout.PREFERRED_SIZE, 272, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(29, 29, 29))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(BTcancelar)
                        .addGap(100, 100, 100)
                        .addComponent(BTcriar)
                        .addGap(58, 58, 58))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(jLabel2)
                        .addGap(152, 152, 152))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addComponent(jLabel2)
                .addGap(28, 28, 28)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtNomeGrupo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel1))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 32, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(BTcancelar)
                    .addComponent(BTcriar))
                .addGap(22, 22, 22))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void BTcriarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BTcriarActionPerformed
        Grupo novo = new Grupo(txtNomeGrupo.getText(), this.atual);
        Rede.dados.adicionarGrupo(novo);
        this.atual.adicionarGrupo(novo);
        novo.adicionarAdminstrador(this.atual);
        novo.adicionarParticipante(this.atual);
        Rede.dados.serializar();
        System.out.println(this.atual.getNome() + " foi adicionado ao grupo " + novo.getTitulo());
        dispose();
        DialogGrupos nova = new DialogGrupos(null, true, this.atual);
        nova.setLocationRelativeTo(null);
        nova.setVisible(true);
    }//GEN-LAST:event_BTcriarActionPerformed

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton BTcancelar;
    private javax.swing.JButton BTcriar;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JTextField txtNomeGrupo;
    // End of variables declaration//GEN-END:variables
}
