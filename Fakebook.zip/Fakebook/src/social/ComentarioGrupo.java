package social;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Jorge Gomes & Naiara Brito
 */
public class ComentarioGrupo {
    
    private Usuario autor;
    private Grupo grupo;
    private String conteudo;
    private List<Resposta> respostas; 
    
    /**
     *
     * @param grupo
     * @param autor
     * @param conteudo
     * @param respostas
     */
    public ComentarioGrupo(Grupo grupo, Usuario autor, String conteudo, ArrayList<Resposta> respostas) {
        this.conteudo = conteudo;
        this.autor = autor;
        this.grupo = grupo;
        this.respostas = new ArrayList<Resposta>();
}

    /**
     *
     * @return
     */
    public Usuario getAutor() {
        return autor;
    }

    /**
     *
     * @param autor
     */
    public void setAutor(Usuario autor) {
        this.autor = autor;
    }

    /**
     *
     * @return
     */
    public String getConteudo() {
        return conteudo;
    }

    /**
     *
     * @param conteudo
     */
    public void setConteudo(String conteudo) {
        this.conteudo = conteudo;
    }

    /**
     *
     * @return
     */
    public List<Resposta> getRespostas() {
        return respostas;
    }

    /**
     *
     * @param respostas
     */
    public void setRespostas(ArrayList<Resposta> respostas) {
        this.respostas = respostas;
    }
    
    /**
     *
     * @param resposta
     */
    public void adicionarResposta(Resposta resposta){
        this.respostas.add(resposta);
    }

    /**
     *
     * @return
     */
    public Grupo getGrupo() {
        return grupo;
    }

    /**
     *
     * @param grupo
     */
    public void setGrupo(Grupo grupo) {
        this.grupo = grupo;
    }
    
    /**
     *
     * @param resposta
     */
    public void removerResposta (RespostaGrupo resposta){
        this.respostas.remove(resposta);
    }
}
