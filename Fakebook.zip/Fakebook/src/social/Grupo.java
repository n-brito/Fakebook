package social;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Jorge Gomes & Naiara Brito
 */
public class Grupo implements Serializable {
    
    private String titulo;
    private List<Usuario> participantes;
    private Usuario administradorUm;
    private List<Usuario> administradores;
    private List<Usuario> solicitacoes;
    private List<Usuario> bloqueados;
    private List<PublicacaoGrupo> publicacoes;
    
    /**
     *
     * @param titulo
     * @param admininstradorUm
     */
    public Grupo(String titulo, Usuario admininstradorUm ) {
    
    
    this.titulo = titulo;
    this.administradorUm = admininstradorUm;
    this.bloqueados = new ArrayList<Usuario>();
    this.solicitacoes = new ArrayList<Usuario>();
    this.administradores = new ArrayList<Usuario>();
    this.participantes = new ArrayList<Usuario>();
    this.publicacoes = new ArrayList<PublicacaoGrupo>();
}

    /**
     *
     * @param publicação
     */
    public void adicionarPubliAoMural(PublicacaoGrupo publicação){
            this.publicacoes.add(publicação);
        }

    /**
     *
     * @param participante
     */
    public void adicionarParticipante(Usuario participante){
            this.participantes.add(participante);
        }

    /**
     *
     * @param administrador
     */
    public void adicionarAdminstrador(Usuario administrador){
            this.administradores.add(administrador);
        }

    /**
     *
     * @param participante
     */
    public void removerParticipante(Usuario participante){
            this.administradores.remove(participante);
    }

    /**
     *
     * @param usuario
     */
    public void adicionarBloqueado(Usuario usuario){
        this.bloqueados.add(usuario);
    }

    /**
     *
     * @param usuario
     */
    public void removerAdministrador(Usuario usuario){
        this.administradores.remove(usuario);
    }

    /**
     *
     * @param usuario
     */
    public void removerSocilitacao(Usuario usuario){
        this.solicitacoes.remove(usuario);
    }

    /**
     *
     * @param administrador
     * @param publicacao
     */
    public void removerPublicacao(Usuario administrador, PublicacaoGrupo publicacao){
        if(this.administradores.contains(administrador)){
            this.publicacoes.remove(publicacao);       
        }
    }

    /**
     *
     * @return
     */
    public String getTitulo() {
        return titulo;
    }

    /**
     *
     * @param titulo
     */
    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    /**
     *
     * @return
     */
    public List<Usuario> getParticipantes() {
        return participantes;
    }

    /**
     *
     * @param participantes
     */
    public void setParticipantes(ArrayList<Usuario> participantes) {
        this.participantes = participantes;
    }

    /**
     *
     * @return
     */
    public List<Usuario> getAdministradores() {
        return administradores;
    }

    /**
     *
     * @param administradores
     */
    public void setAdministradores(ArrayList<Usuario> administradores) {
        this.administradores = administradores;
    }

    /**
     *
     * @return
     */
    public List<PublicacaoGrupo> getPublicacoes() {
        return publicacoes;
    }

    /**
     *
     * @param publicacoes
     */
    public void setPublicacoes(List<PublicacaoGrupo> publicacoes) {
        this.publicacoes = publicacoes;
    }

    /**
     *
     * @param usuario
     */
    public void adicionarSolicitacao(Usuario usuario){
        this.solicitacoes.add(usuario);
    }

    /**
     *
     * @return
     */
    public Usuario getAdministradorUm() {
        return administradorUm;
    }

    /**
     *
     * @param administradorUm
     */
    public void setAdministradorUm(Usuario administradorUm) {
        this.administradorUm = administradorUm;
    }

    /**
     *
     * @return
     */
    public List<Usuario> getSolicitacoes() {
        return solicitacoes;
    }

    /**
     *
     * @param solicitacoes
     */
    public void setSolicitacoes(List<Usuario> solicitacoes) {
        this.solicitacoes = solicitacoes;
    }

    /**
     *
     * @return
     */
    public List<Usuario> getBloqueados() {
        return bloqueados;
    }

    /**
     *
     * @param bloqueados
     */
    public void setBloqueados(List<Usuario> bloqueados) {
        this.bloqueados = bloqueados;
    }

    /**
     *
     * @param usuario
     */
    public void removerBloqueado (Usuario usuario) {
        this.bloqueados.remove(usuario);
        
    }
    
    /**
     *
     * @param publicacao
     */
    public void removerPublicacao(PublicacaoGrupo publicacao){
        this.publicacoes.remove(publicacao);
    }
    
}
