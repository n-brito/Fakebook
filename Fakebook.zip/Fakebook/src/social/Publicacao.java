package social;

import java.io.File;
import java.io.Serializable;
import java.util.ArrayList;
import javax.swing.ImageIcon;


/**
 *
 * @author Jorge Gomes & Naiara Brito
 */
public class Publicacao implements Serializable {

    private String titulo;
    private Usuario autor;
    private Usuario donoDoMural;
    private String conteudo;
    private boolean publica;
    private ArrayList<Comentario> comentarios;
    private ArrayList<File> fotos;
    private Grupo grupo;
    private ImageIcon foto;
            
    /**
     * @param titulo
     * @param autor
     * @param donoDoMural
     * @param conteudo
     * @param icone
     */
    
    
    public Publicacao(String titulo, Usuario autor, Usuario donoDoMural, String conteudo, ImageIcon icone){
        
        this.titulo = titulo;
        this.conteudo = conteudo;
        this.autor = autor;
        this.donoDoMural = donoDoMural;
        this.comentarios = new ArrayList<Comentario>();
        this.foto = icone;
    }
    
    /**
     *
     * @return
     */
    public Usuario getDonoDoMural() {
        return donoDoMural;
    }

    /**
     *
     * @param donoDoMural
     */
    public void setDonoDoMural(Usuario donoDoMural) {
        this.donoDoMural = donoDoMural;
    }

    /**
     *
     * @return
     */
    public String getConteudo() {
        return conteudo;
    }

    /**
     *
     * @param content
     */
    public void setConteudo(String content) {
        this.conteudo = content;
    }

    /**
     *
     * @return
     */
    public Usuario getAutor() {
        return autor;
    }

    /**
     *
     * @param autor
     */
    public void setAutor(Usuario autor) {
        this.autor = autor;
    }

    /**
     *
     * @return
     */
    public boolean ePublica() {
        return publica;
    }

    /**
     *
     * @param publica
     */
    public void setPublica(boolean publica) {
        this.publica = publica;
    }

    /**
     *
     * @return
     */
    public ArrayList<Comentario> getComentarios() {
        return comentarios;
    }

    /**
     *
     * @param comentarios
     */
    public void setComentarios(ArrayList<Comentario> comentarios) {
        this.comentarios = comentarios;
    }

    /**
     *
     * @return
     */
    public ArrayList<File> getFotos() {
        return fotos;
    }

    /**
     *
     * @param fotos
     */
    public void setFotos(ArrayList<File> fotos) {
        this.fotos = fotos;
    }

    /**
     *
     * @return
     */
    public String getTitulo() {
        return titulo;
    }

    /**
     *
     * @param titulo
     */
    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    /**
     *
     * @return
     */
    public ImageIcon getFoto() {
        return foto;
    }

    /**
     *
     * @param foto
     */
    public void setFoto(ImageIcon foto) {
        this.foto = foto;
    }
    
    
}