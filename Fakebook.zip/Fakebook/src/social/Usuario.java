package social;

import java.io.Serializable;
import java.io.File;
import java.util.ArrayList;
import java.util.List;
import javax.swing.ImageIcon;


/**
 *
 * @author Jorge Gomes & Naiara Brito
 */
public class Usuario implements Serializable {
    
    private String nome;
    private String apelido;
    private String senha;
    private String biografia;
    private boolean publico;
    private ImageIcon fotoPerfil;
    private List<Grupo> grupos; 
    private Mural mural;
    private List<Usuario> amigos; 
    private List<Usuario> solicitacoes; 
    private List<Usuario> bloqueados;
    private ArrayList<Publicacao> publicacao;
    
    /**
     *
     * @param nome
     * @param apelido
     * @param senha
     */
    public Usuario (String nome, String apelido, String senha) {

        this.nome = nome;
        this.apelido = apelido;
        this.senha = senha; 
        this.publico = true;
        this.grupos = new ArrayList<Grupo>();
        this.mural = new Mural();
        this.bloqueados = new ArrayList<Usuario>();
        this.amigos = new ArrayList<Usuario>();
        this.publicacao = new ArrayList<Publicacao>();
        this.solicitacoes = new ArrayList<Usuario>();
}

    /**
     *
     * @return
     */
    public String getSenha() {
        return senha;
    }

    /**
     *
     * @param senha
     */
    public void setSenha(String senha) {
        this.senha = senha;
    }
    
    /**
     *
     * @return
     */
    public String getApelido() {
        return apelido;
    }

    /**
     *
     * @param apelido
     */
    public void setUsername(String apelido) {
        this.apelido = apelido;
    }

    /**
     *
     * @param bloqueado
     */
    public void desbloquearUsuario(Usuario bloqueado){
        this.bloqueados.remove(bloqueado);
    }
    
    /**
     *
     * @param bloqueado
     */
    public void bloquearUsuario(Usuario bloqueado){
        this.bloqueados.add(bloqueado);
    }
    
    /**
     *
     * @param publicacao
     */
    public void adicionarPublicacaoAoMural(Publicacao publicacao){
        this.mural.addPubli(publicacao);
    }    
    
    /**
     *
     * @return 
     */
    public String getNome() {
        return nome;
}
    
    /**
     *
     * @param nome
     */
    public void setNome(String nome) {
        this.nome = nome;
}
  
    /**
     *
     * @return 
     */
    public String getBiografia() {
        return biografia;
    }
    
    /**
     *
     * @param biografia
     */
    public void setBiografia(String biografia) {
        this.biografia = biografia;
}

    /**
     *
     * @return
     */
    public List<Grupo> getGrupos() {
        return grupos;
    }

    /**
     *
     * @param grupos
     */
    public void setGrupos(ArrayList<Grupo> grupos) {
        this.grupos = grupos;
    }

    /**
     *
     * @return
     */
    public Mural getMural() {
        return mural;
    }

    /**
     *
     * @param mural
     */
    public void setMural(Mural mural) {
        this.mural = mural;
    }

    /**
     *
     * @return
     */
    public boolean ePublico() {
        return publico;
    }

    /**
     *
     * @param publico
     */
    public void setPublico(boolean publico) {
        this.publico = publico;
    }

    /**
     *
     * @return
     */
    public List<Usuario> getAmigos() {
        return amigos;
    }

    /**
     *
     * @param amigos
     */
    public void setAmigos(ArrayList<Usuario> amigos) {
        this.amigos = amigos;
    }
    
    /**
     *
     * @param amigo
     */
    public void adicionarSolicitacao(Usuario amigo){               
        this.solicitacoes.add(amigo);
    }

    /**
     *
     * @param amigo
     */
    public void adicionarAmigo(Usuario amigo){
        this.amigos.add(amigo);
        amigo.amigos.add(this);
    }
    
    /**
     *
     * @param amigo
     */
    public void removerAmigo(Usuario amigo){
        this.amigos.remove(amigo);
    }
    
    /**
     *
     * @param amigo
     */
    public void listarAmigos(Usuario amigo){
        for (Usuario x : this.amigos) {
            System.out.println(x);
        }
    }    
  
    /**
     *
     * @param amigo
     * @return
     */
    public boolean temAmigo(Usuario amigo){
        for(Usuario x : this.amigos){
            if(x.getNome().equalsIgnoreCase(amigo.getNome().trim())){
                return true;
            }     
        }
        return false;
    }    

    /**
     *
     * @param usuario
     */
    public void eliminarSolicitacao(Usuario usuario){
        solicitacoes.remove(usuario);
    }

    /**
     *
     * @return
     */
    public List<Usuario> getSolicitacoes() {
        return solicitacoes;
    }

    /**
     *
     * @param solicitacoes
     */
    public void setSolicitacoes(List<Usuario> solicitacoes) {
        this.solicitacoes = solicitacoes;
    }

    /**
     *
     * @return
     */
    public List<Usuario> getBloqueados() {
        return bloqueados;
    }

    /**
     *
     * @param bloqueados
     */
    public void setBloqueados(List<Usuario> bloqueados) {
        this.bloqueados = bloqueados;
    }

    /**
     *
     * @return
     */
    public ArrayList<Publicacao> getPublicacao() {
        return publicacao;
    }
    
    /**
     *
     * @param publicacao
     */
    public void addPublicacao(Publicacao publicacao){
        this.publicacao.add(publicacao);     
    }

    /**
     *
     * @param publicacao
     */
    public void setPublicacao(ArrayList<Publicacao> publicacao) {
        this.publicacao = publicacao;
    }
    
    /**
     *
     * @param grupo
     */
    public void adicionarGrupo(Grupo grupo){
        this.grupos.add(grupo);
    }

    /**
     *
     * @return
     */
    public ImageIcon getFotoPerfil() {
        return fotoPerfil;
    }

    /**
     *
     * @param fotoPerfil
     */
    public void setFotoPerfil(ImageIcon fotoPerfil) {
        this.fotoPerfil = fotoPerfil;
    }

}

