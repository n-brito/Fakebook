package social;

import java.io.Serializable;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.List;

/**
 *
 * @author Jorge Gomes & Naiara Brito
 */
public class Dados implements Serializable {
    
    private List<Usuario> usuarios;
    private List<Grupo> grupos;
    private static final String nomeBanco = "banco.ser";
    
 
    public Dados() {
        this.usuarios = new ArrayList<Usuario>();
        this.grupos = new ArrayList<Grupo>();
    }

    /**
     *
     * @param usuario
     */
    public void adicionarUsuario(Usuario usuario) {
        this.usuarios.add(usuario);
    }

    /**
     *
     * @return
     */
    public int numerosDeUsuarios() {
        return this.usuarios.size();
    }
    
    /**
     *
     * @param usuario
     * @return
     */
    public Usuario temUsuario(Usuario usuario) {
        for (Usuario x : this.usuarios) {
            if (x.getApelido().equalsIgnoreCase(usuario.getApelido().trim())) {
                return x;
            }
        }
        
        return null;
    }
    
    /**
     *
     * @param grupo
     * @return
     */
    public Grupo temGrupo(Grupo grupo) {
        for (Grupo x : this.grupos) {
            if (x.getTitulo().equalsIgnoreCase(grupo.getTitulo().trim())) {
                return x;
            }
        }
        
        return null;
    }

    /**
     *
     * @return
     */
    public List<Usuario> getUsuarios() {
        return usuarios;
    }

    /**
     *
     * @param usuarios
     */
    public void setUsuarios(List<Usuario> usuarios) {
        this.usuarios = usuarios;
    }

    /**
     *
     * @return
     */
    public List<Grupo> getGrupos() {
        return grupos;
    }

    /**
     *
     * @param grupos
     */
    public void setGrupos(List<Grupo> grupos) {
        this.grupos = grupos;
    }
    
    /**
     *
     */
    public void serializar() {
      File arq = new File(nomeBanco);

      try {    
        ObjectOutputStream objOutput = new ObjectOutputStream(new FileOutputStream(arq));
        objOutput.writeObject(this);
        objOutput.close();
    
      } catch(IOException erro) {
          System.out.printf("Erro: %s", erro.getMessage());
      }         
      }
    
    /**
     *
     * @return
     */
    public Dados deserializar() {
        Dados rede = null;
        try {
            ObjectInputStream objInput = new ObjectInputStream(new FileInputStream(nomeBanco));
            rede = (Dados)objInput.readObject();
            objInput.close();        
        } catch(IOException erro1) {
            System.out.printf("Erro: %s", erro1.getMessage());
        } catch(ClassNotFoundException erro2) {
            System.out.printf("Erro: %s", erro2.getMessage());
        }
    
      return rede;
    }
    
    /**
     *
     * @param grupo
     */
    public void adicionarGrupo(Grupo grupo){
        this.grupos.add(grupo);
    }
    
    /**
     *
     * @param grupo
     */
    public void removerGrupo(Grupo grupo){
        this.grupos.remove(grupo);
    }
    
    /**
     *
     * @param verificado
     * @return
     */
    public boolean verificacaoMesmoApelido(Usuario verificado){
        if(this.usuarios.equals(verificado)){
            return true;
        }else{
            return false;
        }
    }
}
