package social;

import java.io.Serializable;
import java.util.ArrayList;

/**
 *
 * @author Jorge Gomes & Naiara Brito
 */
public class Mural implements Serializable {
     
    private ArrayList<Publicacao> publicações;
    
    /**
     *
     */
    public Mural() {
        this.publicações = new ArrayList<Publicacao>();
    }
    
    /**
     *
     * @param publicações
     */
    public Mural(ArrayList<Publicacao> publicações) {
        this.publicações = publicações;
    }
        
    /**
     *
     * @param publicações
     */
    public void addPubli(Publicacao publicações){
       this.publicações.add(publicações);
    }
    
    /**
     *
     * @param publicação
     */
    public void removerPublicação(Publicacao publicação){
        this.publicações.remove(publicação);
    }

    /**
     *
     * @return
     */
    public ArrayList<Publicacao> getPublicacoes() {
        return publicações;
    }

    /**
     *
     * @param publicações
     */
    public void setPublicações(ArrayList<Publicacao> publicações) {
        this.publicações = publicações;
    }
    
}
