package social;

/**
 *
 * @author Jorge Gomes & Naiara Brito
 */
public class RespostaGrupo {
    
    private Usuario autor;
    private String conteudo;
  
    /**
     *
     * @param autor
     * @param conteudo
     */
    public RespostaGrupo(Usuario autor, String conteudo) {
        this.conteudo = conteudo;
        this.autor = autor;
}

    /**
     *
     * @return
     */
    public Usuario getAutor() {
        return autor;
    }

    /**
     *
     * @param autor
     */
    public void setAutor(Usuario autor) {
        this.autor = autor;
    }

    /**
     *
     * @return
     */
    public String getConteudo() {
        return conteudo;
    }

    /**
     *
     * @param conteudo
     */
    public void setConteudo(String conteudo) {
        this.conteudo = conteudo;
    }
    
}
