package social;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;

/**
 *
 * @author Jorge Gomes & Naiara Brito
 */
public class Rede {

    
    public static Dados dados = deserializar();
    private static final String nomeBanco = "banco.ser";
            
            
    private static Dados deserializar() {
      Dados rede = null;
      try {
        ObjectInputStream objInput = new ObjectInputStream(new FileInputStream(nomeBanco));
        rede = (Dados)objInput.readObject();
        objInput.close();        
      } catch(IOException erro1) {
          System.out.printf("Erro: %s", erro1.getMessage());
      } catch(ClassNotFoundException erro2) {
          System.out.printf("Erro: %s", erro2.getMessage());
      }
    
      return rede;
    }
}
