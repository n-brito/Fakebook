package social;

import java.io.File;
import java.io.Serializable;
import java.util.ArrayList;
import javax.swing.ImageIcon;

/**
 *
 * @author Jorge Gomes & Naiara Brito
 */
public class PublicacaoGrupo implements Serializable {
    
    private String titulo;
    private Usuario autor;   
    private String conteudo;
    private ArrayList<Comentario> comentarios;
    private Grupo grupo;
    private ImageIcon foto;
    
    /**
     *
     * @param titulo
     * @param autor
     * @param grupo
     * @param conteudo
     * @param foto
     */
    public PublicacaoGrupo(String titulo, Usuario autor, Grupo grupo, String conteudo, ImageIcon foto){
        
        this.titulo = titulo;
        this.conteudo = conteudo;
        this.autor = autor;
        this.grupo = grupo;
        this.comentarios = new ArrayList<Comentario>();
        this.foto = foto;
    }
    
    /**
     *
     * @return
     */
    public Grupo getGrupo() {
        return grupo;
    }

    /**
     *
     * @param grupo
     */
    public void setGrupo(Grupo grupo) {
        this.grupo = grupo;
    }

    /**
     *
     * @return
     */
    public String getConteudo() {
        return conteudo;
    }

    /**
     *
     * @param content
     */
    public void setConteudo(String content) {
        this.conteudo = content;
    }

    /**
     *
     * @return
     */
    public Usuario getAutor() {
        return autor;
    }

    /**
     *
     * @param autor
     */
    public void setAutor(Usuario autor) {
        this.autor = autor;
    }

    /**
     *
     * @return
     */
    public ArrayList<Comentario> getComentarios() {
        return comentarios;
    }

    /**
     *
     * @param comentarios
     */
    public void setComentarios(ArrayList<Comentario> comentarios) {
        this.comentarios = comentarios;
    }

    /**
     *
     * @return
     */
    public String getTitulo() {
        return titulo;
    }

    /**
     *
     * @param titulo
     */
    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    /**
     *
     * @return
     */
    public ImageIcon getFoto() {
        return foto;
    }

    /**
     *
     * @param foto
     */
    public void setFone(ImageIcon foto) {
        this.foto = foto;
    }
    
    /**
     *
     * @param comentario
     */
    public void removerComentario(ComentarioGrupo comentario){
        this.comentarios.remove(comentario);
    }
    
}
    
