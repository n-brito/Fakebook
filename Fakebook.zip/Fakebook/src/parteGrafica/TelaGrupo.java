package parteGrafica;

import JDialogs.DialogListaUsuarios;
import JDialogs.DialogListarUsuariosAdm;
import JDialogs.DialogPost;
import JDialogs.DialogPostGrupo;
import java.util.ArrayList;
import java.util.List;
import parteGrafica.TelaDePerfil;
import social.Grupo;
import social.Publicacao;
import social.PublicacaoGrupo;
import social.Rede;
import static social.Rede.dados;
import social.Usuario;

/**
 *
 * @author Jorge Gomes & Naiara Brito
 */
public class TelaGrupo extends javax.swing.JFrame {

    /**
     * Creates new form TelaGrupo
     */
    
    private Grupo grupo;
    private Usuario usuario;
    private List<Publicacao> publicacoes;
    
    /**
     *
     * @param grupo
     * @param usuario
     */
    public TelaGrupo(Grupo grupo, Usuario usuario) {
        initComponents();
        
        this.usuario = usuario;
        this.publicacoes = new ArrayList<Publicacao>();
        this.grupo = grupo;
        
        lblTituloGrupo.setText(grupo.getTitulo());
        atualizarTelaGrupo();
    }
    
    /**
     *
     */
    public void atualizarTelaGrupo(){
        for(PublicacaoGrupo x: grupo.getPublicacoes()){
            PostGrupo y = new PostGrupo(x, jpnlMural, usuario, grupo);
            jpnlMural.add(y);
        }
        revalidate();
        repaint();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        lblTituloGrupo = new javax.swing.JLabel();
        BTnovoPostGrupo = new javax.swing.JButton();
        BTvoltar = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jpnlMural = new javax.swing.JPanel();
        jButton1 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(218, 244, 248));

        lblTituloGrupo.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        lblTituloGrupo.setText("Título do grupo");

        BTnovoPostGrupo.setText("Novo post");
        BTnovoPostGrupo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BTnovoPostGrupoActionPerformed(evt);
            }
        });

        BTvoltar.setText("Voltar");
        BTvoltar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BTvoltarActionPerformed(evt);
            }
        });

        jButton2.setText("Listar Usuários");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jpnlMural.setLayout(new javax.swing.BoxLayout(jpnlMural, javax.swing.BoxLayout.Y_AXIS));
        jScrollPane1.setViewportView(jpnlMural);

        jButton1.setText("Sair do grupo");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jScrollPane1)
                        .addContainerGap())
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(BTvoltar)
                        .addGap(258, 258, 258)
                        .addComponent(lblTituloGrupo)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 298, Short.MAX_VALUE)
                        .addComponent(BTnovoPostGrupo)
                        .addGap(28, 28, 28)
                        .addComponent(jButton2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 107, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(61, 61, 61))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblTituloGrupo)
                    .addComponent(BTvoltar)
                    .addComponent(jButton1)
                    .addComponent(jButton2)
                    .addComponent(BTnovoPostGrupo))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 544, Short.MAX_VALUE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void BTnovoPostGrupoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BTnovoPostGrupoActionPerformed
        DialogPostGrupo dialogo = new DialogPostGrupo(this,true,usuario ,grupo, jpnlMural);
        dialogo.setLocationRelativeTo(null);
        dialogo.setVisible(true);
    }//GEN-LAST:event_BTnovoPostGrupoActionPerformed

    private void BTvoltarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BTvoltarActionPerformed
        //TelaDePerfil.atualizartela();
        Rede.dados.serializar();
        dispose();
    }//GEN-LAST:event_BTvoltarActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        if(grupo.getAdministradores().contains(usuario)){
            DialogListarUsuariosAdm novo = new DialogListarUsuariosAdm(null,true, this.grupo, this.usuario);
            novo.setLocationRelativeTo(null);
            novo.setVisible(true);
        }else{
            DialogListaUsuarios novo = new DialogListaUsuarios(null,true, this.grupo, this.usuario);
            novo.setLocationRelativeTo(null);
            novo.setVisible(true);
        }
    dispose();
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        //Se o grupo tiver um número de administradores menor que um, ele será excluído.
        if(this.grupo.getAdministradores().size() > 0){
            this.grupo.removerParticipante(usuario);
            if(this.grupo.getAdministradores().contains(this.usuario)){
                grupo.removerAdministrador(this.usuario);
                dados.removerGrupo(this.grupo);
            }
        }
        dispose();
    }//GEN-LAST:event_jButton1ActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton BTnovoPostGrupo;
    private javax.swing.JButton BTvoltar;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JPanel jpnlMural;
    private javax.swing.JLabel lblTituloGrupo;
    // End of variables declaration//GEN-END:variables
}
